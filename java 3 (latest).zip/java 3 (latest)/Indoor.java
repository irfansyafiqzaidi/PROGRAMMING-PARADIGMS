class Indoor extends Equipment {
    public Indoor(String name, int quantity) {
        super(name, quantity);
    }

    @Override
    public String getType() {
        return "Indoor";
    }
}