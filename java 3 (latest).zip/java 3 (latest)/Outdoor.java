class Outdoor extends Equipment {
    public Outdoor(String name, int quantity) {
        super(name, quantity);
    }

    @Override
    public String getType() {
        return "Outdoor";
    }
}