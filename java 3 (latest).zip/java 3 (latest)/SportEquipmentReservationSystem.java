import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.util.InputMismatchException;

public class SportEquipmentReservationSystem {
    private static List<Equipment> equipmentList = new ArrayList<>();
    private static Scanner scanner = new Scanner(System.in);

    public static void main(String[] args) {
        initializeEquipment();
        int choice;
        do {
            displayMenu();
            choice = getIntInput("Enter your choice: ");

            switch (choice) {
                case 1:
                    getInfo();
                    break;
                case 2:
                    returnEquipment();
                    break;
                case 3:
                    displayEquipment();
                    break;
                case 4:
                    System.out.println("Exiting the system. Goodbye!");
                    break;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        } while (choice != 4);
    }

    private static void initializeEquipment() {
        equipmentList.add(new Outdoor("soccer ball", 20));
        equipmentList.add(new Outdoor("basketball", 20));
        equipmentList.add(new Outdoor("tennis racket", 15));
        equipmentList.add(new Outdoor("tennis ball", 10));
        equipmentList.add(new Outdoor("badminton racket", 30));
        equipmentList.add(new Outdoor("badminton shuttle", 100));
        equipmentList.add(new Outdoor("volleyball", 20));
        equipmentList.add(new Outdoor("netball", 20));
        equipmentList.add(new Indoor("chess set", 15));
        equipmentList.add(new Indoor("scrabble", 30));
        equipmentList.add(new Indoor("snooker", 20));
        equipmentList.add(new Indoor("carrom", 50));
        equipmentList.add(new Indoor("monopoly", 25));
        equipmentList.add(new Indoor("batu seremban", 10));
        equipmentList.add(new Indoor("foosball table", 5));
        equipmentList.add(new Indoor("congkak", 20));
    }

    private static void displayMenu() {
        System.out.println("=====================================");
        System.out.println(" Sport Equipments Reservation System");
        System.out.println("=====================================\n");
        System.out.println("  1. Make a reservation");
        System.out.println("  2. Return equipment");
        System.out.println("  3. View inventory");
        System.out.println("  4. Exit\n");
        System.out.println("=====================================\n");
        System.out.print("Enter your choice: ");
    }
    private static void getInfo() {
        int studentID = getIntInput("Enter your student ID number: ");
        System.out.println();
        makeReservation(studentID);
    }

    private static void makeReservation(int studentID) {
        displayEquipment();
        int equipmentNumber = getIntInput("Enter the equipment number: ") - 1; // convert to zero-indexed
        int units = getIntInput("Enter the number of units: ");

        if (equipmentNumber >= 0 && equipmentNumber < equipmentList.size() && units > 0 && units <= equipmentList.get(equipmentNumber).getQuantity()) {
            Equipment equipment = equipmentList.get(equipmentNumber);
            equipment.setQuantity(equipment.getQuantity() - units);
            System.out.println("\nStudent ID number: " + studentID);
            System.out.println("Reservation made successfully!");
            System.out.println("Please return the equipment within 3 hours.\n");
        } else {
            System.out.println("Reservation failed. Invalid equipment or units.\n");
        }
    }

    private static void returnEquipment() {
        displayEquipment();
        int equipmentNumber = getIntInput("Enter the equipment number: ") - 1; // convert to zero-indexed
        int units = getIntInput("Enter the number of units: ");

        if (equipmentNumber >= 0 && equipmentNumber < equipmentList.size() && units > 0) {
            Equipment equipment = equipmentList.get(equipmentNumber);
            equipment.setQuantity(equipment.getQuantity() + units);
            System.out.println("\nEquipment returned successfully!\n");
        } else {
            System.out.println("Return of equipment failed. Invalid equipment or units.\n");
        }
    }

    private static void displayEquipment() {
        System.out.println("=====================================");
        System.out.println("       Available equipments:");
        System.out.println("=====================================\n");

        for (int i = 0; i < equipmentList.size(); i++) {
            Equipment equipment = equipmentList.get(i);
            System.out.printf("  %d. %s: %d\n", i + 1, equipment.getName(), equipment.getQuantity());
        }

        int[] counts = countEquipment();
        System.out.println("\n=====================================");
        System.out.println("Equipment Summary:");
        System.out.println("-------------------------------------");
        System.out.println("Outdoor Sports Equipment: " + counts[0]);
        System.out.println("Indoor Sports Equipment: " + counts[1]);
        System.out.println("=====================================\n");
    }

    private static int[] countEquipment() {
        int outdoorCount = 0;
        int indoorCount = 0;

        for (Equipment equipment : equipmentList) {
            if (equipment instanceof Outdoor) {
                outdoorCount += equipment.getQuantity();
            } else if (equipment instanceof Indoor) {
                indoorCount += equipment.getQuantity();
            }
        }

        return new int[]{outdoorCount, indoorCount};
    }

    private static int getIntInput(String prompt) {
        while (true) {
            try {
                System.out.print(prompt);
                return scanner.nextInt();
            } catch (InputMismatchException e) {
                System.out.println("Invalid input. Please enter a number.");
                scanner.nextLine(); // Clear the invalid input
            }
        }
    }
}